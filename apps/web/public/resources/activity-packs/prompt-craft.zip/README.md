# Open Practice / Prompt craft

Five guided activities. Open the Markdown handbooks, input fixtures and SVG visual guides in your normal reader/browser. Provider tools and cloud inference are separate; no models or credentials are included. All examples are original/fictional. Self-reported practice, not accredited assessment. CC BY 4.0.
